import { Routes, Route } from "react-router-dom";
import routes from "./routes";
import Layout from "./components/Layout";
import ProtectedRoute from "./components/ProtectedRoute";

// Public pages
import HomePage from "./pages/HomePage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";

// Buyer product pages
import BuyerProductsPage from "./pages/buyer/BuyerProductsPage";
import BuyerProductDetailPage from "./pages/buyer/BuyerProductDetailPage";
import ShopDetailPage from "./pages/buyer/ShopDetailPage";

// Cart
import CartPage from "./pages/CartPage";

// Protected (buyer)
import CheckoutPage from "./pages/checkout/CheckoutPage";
import OrdersListPage from "./pages/orders/OrdersListPage";
import OrderDetailPage from "./pages/orders/OrderDetailPage";

// Seller shop pages
import ShopDashboard from "./pages/shops/ShopDashboard";
import ShopCreatePage from "./pages/shops/ShopCreatePage";
import ShopEditPage from "./pages/shops/ShopEditPage";

// Seller product pages
import MyProductsPage from "./pages/seller/MyProductsPage";
import ProductCreatePage from "./pages/seller/ProductCreatePage";
import ProductEditPage from "./pages/seller/ProductEditPage";

// Category & tag creation
import CategoryCreatePage from "./pages/categories/CategoryCreatePage";
import TagCreatePage from "./pages/tags/TagCreatePage";

// Buyer shop detail page 
import BuyerShopDetailPage from './pages/buyer/ShopDetailPage';

function App() {
  return (
    <Layout>
      <Routes>
        {/* Public Routes */}
        <Route path={routes.home} element={<HomePage />} />
        <Route
          path={routes.login}
          element={
            <ProtectedRoute type="auth">
              <LoginPage />
            </ProtectedRoute>
          }
        />
        <Route
          path={routes.register}
          element={
            <ProtectedRoute type="auth">
              <RegisterPage />
            </ProtectedRoute>
          }
        />
        {/* Buyer-Facing Shop Detail */}
        <Route path="/buyer/shops/:id" element={<BuyerShopDetailPage />} />
        {/* Buyer-Facing Product Routes */}
        <Route path={routes.products} element={<BuyerProductsPage />} />
        <Route path={routes.productDetail(":id")} element={<BuyerProductDetailPage />} />
        <Route path={routes.shopDetail(":id")} element={<ShopDetailPage />} />

        {/* Cart & Checkout */}
        <Route path={routes.cart} element={<CartPage />} />
        <Route
          path={routes.checkout}
          element={
            <ProtectedRoute>
              <CheckoutPage />
            </ProtectedRoute>
          }
        />

        {/* Buyer Orders */}
        <Route
          path={routes.orders}
          element={
            <ProtectedRoute>
              <OrdersListPage />
            </ProtectedRoute>
          }
        />
        <Route
          path={routes.orderDetail(":id")}
          element={
            <ProtectedRoute>
              <OrderDetailPage />
            </ProtectedRoute>
          }
        />

        {/* Seller Shop Management */}
        <Route
          path={routes.shopDashboard}
          element={
            <ProtectedRoute requireSeller>
              <ShopDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path={routes.shopCreate}
          element={
            <ProtectedRoute requireSeller>
              <ShopCreatePage />
            </ProtectedRoute>
          }
        />
        <Route
          path={routes.shopEdit}
          element={
            <ProtectedRoute requireSeller>
              <ShopEditPage />
            </ProtectedRoute>
          }
        />

        {/* Seller Product Management */}
        <Route
          path={routes.sellerProducts}
          element={
            <ProtectedRoute requireSeller>
              <MyProductsPage />
            </ProtectedRoute>
          }
        />
        <Route
          path={routes.sellerProductCreate}
          element={
            <ProtectedRoute requireSeller>
              <ProductCreatePage />
            </ProtectedRoute>
          }
        />
        <Route
          path={routes.sellerProductEdit(":id")}
          element={
            <ProtectedRoute requireSeller>
              <ProductEditPage />
            </ProtectedRoute>
          }
        />

        {/* Category & Tag Management */}
        <Route
          path={routes.categoryCreate}
          element={
            <ProtectedRoute requireSeller>
              <CategoryCreatePage />
            </ProtectedRoute>
          }
        />
        <Route
          path={routes.tagCreate}
          element={
            <ProtectedRoute requireSeller>
              <TagCreatePage />
            </ProtectedRoute>
          }
        />
      </Routes>
    </Layout>
  );
}

export default App;
