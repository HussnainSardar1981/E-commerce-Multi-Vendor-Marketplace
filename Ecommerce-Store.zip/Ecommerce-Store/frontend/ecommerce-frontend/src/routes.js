// routes.js

const routes = {
  // Public pages
  home: "/",
  products: "/products",
  productDetail: (id = ":id") => `/buyer/products/${id}`,
  shopDetail: (id) => `/shops/${id}`,

  // Auth
  login: "/login",
  register: "/register",

  // Cart & Checkout
  cart: "/cart",
  checkout: "/checkout",

  // Orders
  orders: "/orders",
  orderDetail: (id) => `/orders/${id}`,

  // Seller Shop (Dashboard)
  shopDashboard: "/seller/shop",
  shopCreate: "/seller/shop/create",
  shopEdit: "/seller/shop/edit",

  // Seller Product Management
  sellerProducts: "/seller/products",
  sellerProductCreate: "/seller/products/create",
  sellerProductEdit: (id) => `/seller/products/${id}/edit`,

  // Seller Category & Tag Management
  categoryCreate: "/category/create",
  tagCreate: "/tags/create",
};

export default routes;
