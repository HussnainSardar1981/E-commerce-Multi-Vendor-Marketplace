import axios from "axios";
import routes from "./routes";

// Create an Axios instance
const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
  withCredentials: true,
  headers: {
    "Content-Type": "application/json",
  },
});

// ✅ Attach access token to every request (if available)
api.interceptors.request.use((config) => {
  const accessToken = localStorage.getItem("ecom_accessToken");
  if (accessToken) {
    config.headers.Authorization = `Bearer ${accessToken}`;
  }
  return config;
});

// 🔁 Automatically refresh token if access token expired
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    // If token expired and we haven't retried yet
    if (
      error.response?.status === 401 &&
      !originalRequest._retry &&
      localStorage.getItem("ecom_refreshToken")
    ) {
      originalRequest._retry = true;

      try {
        const res = await axios.post(
          `${import.meta.env.VITE_API_BASE_URL}/api/accounts/token/refresh/`,
          {
            refresh: localStorage.getItem("ecom_refreshToken"),
          }
        );

        const newAccessToken = res.data.access;

        // 🔄 Update localStorage and retry original request
        localStorage.setItem("ecom_accessToken", newAccessToken);
        originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;

        return api(originalRequest);
      } catch (refreshError) {
        // ❌ Refresh failed, logout user
        localStorage.removeItem("ecom_accessToken");
        localStorage.removeItem("ecom_refreshToken");
        localStorage.removeItem("ecom_user");

        // Redirect to login
        window.location.href = routes.login;
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

export default api;
