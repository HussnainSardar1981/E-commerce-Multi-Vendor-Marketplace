import axios from "../axios";

// Get the cart
export const getCart = () => axios.get("/api/orders/cart/");

// Add a product (or increase quantity if it exists)
export const addToCart = (productId, quantity = 1) =>
  axios.post("/api/orders/cart/add/", { product_id: productId, quantity });

// Set a specific quantity (for + / - buttons)
export const setCartQuantity = (productId, quantity) =>
  axios.post("/api/orders/cart/set_quantity/", { product_id: productId, quantity });

// Remove a product from the cart
export const removeFromCart = (productId) =>
  axios.post("/api/orders/cart/remove/", { product_id: productId });

// ✅ Checkout the cart and create an order
export const checkoutCart = () => axios.post("/api/orders/cart/checkout/");
