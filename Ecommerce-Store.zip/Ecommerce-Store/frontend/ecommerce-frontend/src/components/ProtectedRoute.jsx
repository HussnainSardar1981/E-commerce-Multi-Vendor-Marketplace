import { Navigate, useLocation } from "react-router-dom";
import routes from "../routes";

// Type: 'auth' = only for guests (login/register)
// Type: 'protected' = only for logged-in users (checkout, orders, shop dashboard)
// requireSeller = true ➜ only allow if user is seller
const ProtectedRoute = ({ children, type = "protected", requireSeller = false }) => {
  const location = useLocation();
  const accessToken = localStorage.getItem("ecom_accessToken");
  const user = JSON.parse(localStorage.getItem("ecom_user") || "null");

  const isAuthenticated = !!accessToken;

  // Guest-only (login/register)
  if (type === "auth" && isAuthenticated) {
    return <Navigate to={routes.home} replace />;
  }

  // Authenticated-only
  if (type === "protected" && !isAuthenticated) {
    return <Navigate to={routes.login} state={{ from: location }} replace />;
  }

  // Seller-only route
  if (requireSeller && (!user || !user.is_seller)) {
    return <Navigate to={routes.home} replace />;
  }

  return children;
};

export default ProtectedRoute;
