import { Link } from 'react-router-dom';
import { addToCart } from '../api/cartApi';
import routes from '../routes';


export default function BuyerProductCard({ product }) {
  const handleAddToCart = async () => {
    try {
      await addToCart(product.id, 1);
      alert("Item added to cart");
    } catch (err) {
      console.error("Error adding to cart:", err);
      alert("Failed to add item to cart");
    }
  };

  return (
    <div className="group rounded-xl border p-4 bg-white flex flex-col">
      {/* Only image and title are linked */}
      <Link to={routes.productDetail(product.id)} className="flex-1">
        <img
          src={product.image || 'https://placehold.co/300x300?text=No+Image'}
          alt={product.title}
          className="w-full h-64 object-cover rounded-lg"
        />
        <div className="mt-4">
          <h3 className="text-lg font-semibold text-gray-800 group-hover:text-blue-600 truncate">
            {product.title}
          </h3>
        </div>
      </Link>
      <p className="text-sm text-gray-500">{product.category?.name}</p>
      {/* Seller link separated outside the product Link */}
      <p className="text-sm text-gray-600 mt-2">
        Seller:{' '}
        <Link
          to={`/buyer/shops/${product.shop?.id}`}
          className="text-blue-600 hover:underline"
        >
          {product.shop?.name}
        </Link>
      </p>

      <p className="mt-2 font-bold text-blue-600">${product.price}</p>

      <button
        onClick={handleAddToCart}
        className="mt-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded"
      >
        Add to Cart
      </button>
    </div>
  );
}
