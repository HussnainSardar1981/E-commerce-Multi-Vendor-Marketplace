import { useContext, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import routes from "../routes";
import { getCart } from "../api/cartApi";
import { AuthContext } from "../context/AuthContext";

const Navbar = () => {
  const navigate = useNavigate();
  const { isAuthenticated, user, logout } = useContext(AuthContext);
  const isSeller = user?.is_seller;
  const [cartCount, setCartCount] = useState(0);
  const [navbarOpen, setNavbarOpen] = useState(false);

  useEffect(() => {
    if (isAuthenticated && !isSeller) {
      getCart()
        .then((res) => {
          const items = res.data.items || [];
          const total = items.reduce((sum, item) => sum + item.quantity, 0);
          setCartCount(total);
        })
        .catch(() => setCartCount(0));
    }
  }, [isAuthenticated, isSeller]);

  const handleLogout = () => {
    logout();
    navigate(routes.login);
  };

  return (
    <header className="flex w-full items-center bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <div className="w-40">
            <Link to={routes.home}>
              <img
                src="https://cdn.tailgrids.com/2.0/image/assets/images/logo/logo-primary.svg"
                alt="logo"
                className="h-8"
              />
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setNavbarOpen(!navbarOpen)}
            className="lg:hidden block p-2 rounded-lg focus:outline-none border border-gray-200"
          >
            <span className="block w-6 h-0.5 bg-gray-600 mb-1"></span>
            <span className="block w-6 h-0.5 bg-gray-600 mb-1"></span>
            <span className="block w-6 h-0.5 bg-gray-600"></span>
          </button>

          {/* Nav Links */}
          <nav
            className={`${navbarOpen ? "block" : "hidden"
              } absolute top-full right-4 mt-2 w-64 rounded-lg bg-white p-6 shadow-lg lg:static lg:mt-0 lg:flex lg:w-auto lg:items-center lg:bg-transparent lg:p-0 lg:shadow-none z-50`}
          >
            <ul className="flex flex-col lg:flex-row lg:items-center lg:space-x-8">
              {/* Buyer Navigation */}
              {!isSeller && (
                <>
                  <li>
                    <Link
                      to={routes.products}
                      className="block py-2 text-base font-medium text-gray-700 hover:text-primary"
                    >
                      Products
                    </Link>
                  </li>
                  {isAuthenticated && (
                    <>
                      <li>
                        <Link
                          to={routes.orders}
                          className="block py-2 text-base font-medium text-gray-700 hover:text-primary"
                        >
                          Orders
                        </Link>
                      </li>
                      {cartCount > 0 && (
                        <li>
                          <Link
                            to={routes.checkout}
                            className="block py-2 text-base font-medium text-blue-600 hover:text-blue-800"
                          >
                            Checkout
                          </Link>
                        </li>
                      )}
                    </>
                  )}
                  <li className="relative">
                    <Link
                      to={routes.cart}
                      className="flex items-center gap-1 text-base font-medium text-gray-700 hover:text-primary"
                    >
                      🛒
                      {cartCount > 0 && (
                        <span className="absolute -top-1 -right-2 bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                          {cartCount}
                        </span>
                      )}
                    </Link>
                  </li>
                </>
              )}

              {/* Seller Navigation */}
              {isSeller && (
                <>
                  <li>
                    <Link to={routes.shopDashboard} className="block py-2 text-base font-medium text-green-700 hover:text-green-900">
                      My Shop
                    </Link>
                  </li>
                  <li>
                    <Link to={routes.sellerProducts} className="block py-2 text-base font-medium text-green-700 hover:text-green-900">
                      My Products
                    </Link>
                  </li>
                  <li>
                    <Link to={routes.sellerProductCreate} className="block py-2 text-base font-medium text-green-700 hover:text-green-900">
                      Add Product
                    </Link>
                  </li>
                  <li>
                    <Link to={routes.categoryCreate} className="block py-2 text-base font-medium text-green-700 hover:text-green-900">
                      Add Category
                    </Link>
                  </li>
                  <li>
                    <Link to={routes.tagCreate} className="block py-2 text-base font-medium text-green-700 hover:text-green-900">
                      Add Tag
                    </Link>
                  </li>
                </>
              )}

              {/* Auth Section */}
              {isAuthenticated ? (
                <>
                  <li>
                    <span className="hidden lg:inline text-sm text-gray-600">
                      Welcome, {user?.name}
                    </span>
                  </li>
                  <li>
                    <button
                      onClick={handleLogout}
                      className="text-red-500 hover:text-red-700 font-medium py-2"
                    >
                      Logout
                    </button>
                  </li>
                </>
              ) : (
                <>
                  <li>
                    <Link to={routes.login} className="block py-2 text-base font-medium text-gray-700 hover:text-primary">
                      Login
                    </Link>
                  </li>
                  <li>
                    <Link
                      to={routes.register}
                      className="block text-base font-medium text-white bg-primary px-4 py-1.5 rounded hover:bg-primary/90"
                    >
                      Register
                    </Link>
                  </li>
                </>
              )}
            </ul>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
