// src/context/AuthContext.jsx
import { createContext, useState, useEffect } from "react";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(() =>
    !!localStorage.getItem("ecom_accessToken")
  );
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem("ecom_user");
    return stored ? JSON.parse(stored) : null;
  });

  const login = (userData, access, refresh) => {
    localStorage.setItem("ecom_user", JSON.stringify(userData));
    localStorage.setItem("ecom_accessToken", access);
    localStorage.setItem("ecom_refreshToken", refresh);
    setUser(userData);
    setIsAuthenticated(true);
  };

  const logout = () => {
    localStorage.removeItem("ecom_user");
    localStorage.removeItem("ecom_accessToken");
    localStorage.removeItem("ecom_refreshToken");
    setUser(null);
    setIsAuthenticated(false);
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
