import { createContext, useContext, useEffect, useState } from "react";
import axios from "../axios";
import { useAuth } from "./AuthContext"; // assuming you’ll use auth context too

const CartContext = createContext();

export const useCart = () => useContext(CartContext);

export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState(null);
  const [loading, setLoading] = useState(true);

  // Fetch cart from backend (DB or session)
  const fetchCart = async () => {
    try {
      const res = await axios.get("/api/cart/");
      setCart(res.data);
    } catch (err) {
      console.error("Error fetching cart", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCart();
  }, []);

  // Add product to cart
  const addToCart = async (productId, quantity = 1) => {
    try {
      const res = await axios.post("/api/store/cart/items/", {
        product_id: productId,
        quantity,
      });
      setCart(res.data);
    } catch (err) {
      console.error("Error adding to cart", err);
    }
  };

  // Remove item from cart
  const removeFromCart = async (itemId) => {
    try {
      const res = await axios.delete(`/api/store/cart/items/${itemId}/`);
      setCart(res.data);
    } catch (err) {
      console.error("Error removing from cart", err);
    }
  };

  return (
    <CartContext.Provider
      value={{
        cart,
        loading,
        addToCart,
        removeFromCart,
        refreshCart: fetchCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};
