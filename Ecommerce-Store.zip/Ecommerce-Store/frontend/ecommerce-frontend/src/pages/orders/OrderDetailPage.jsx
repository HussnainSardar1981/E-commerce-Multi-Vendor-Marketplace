import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "../../axios"; // adjust if your Axios instance is elsewhere

function OrderDetailPage() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchOrder = async () => {
      try {
        const response = await axios.get(`/api/orders/${id}/`);
        setOrder(response.data);
      } catch (err) {
        console.error(err);
        setError("Failed to load order.");
      } finally {
        setLoading(false);
      }
    };

    fetchOrder();
  }, [id]);

  if (loading) return <p>Loading order...</p>;
  if (error) return <p>{error}</p>;
  if (!order) return <p>Order not found.</p>;

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-2">Order #{order.id}</h2>
      <p>Date: {new Date(order.created_at).toLocaleString()}</p>
      <p>Status: {order.status || "Pending"}</p>
      <p>Total: ${order.total}</p>

      <h3 className="text-lg font-semibold mt-4 mb-2">Items</h3>
      <ul className="space-y-2">
        {order.items.map((item) => (
          <li key={item.id} className="border p-2 rounded">
            <p className="font-medium">{item.product_title}</p>
            <p>Qty: {item.quantity}</p>
            <p>Price: ${item.price}</p>
            <p>Subtotal: ${item.price * item.quantity}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default OrderDetailPage;
