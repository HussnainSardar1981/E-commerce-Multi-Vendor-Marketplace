import { useEffect, useState } from 'react';
import axios from '../../axios'; // your configured Axios instance
import { useNavigate } from 'react-router-dom';

const OrdersListPage = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [pagination, setPagination] = useState({
    count: 0,
    next: null,
    previous: null,
  });

  const navigate = useNavigate();

  const fetchOrders = async (url = '/api/orders/') => {
    try {
      setLoading(true);
      const response = await axios.get(url);
      console.log('Orders Response:', response.data);

      setOrders(response.data.results);
      setPagination({
        count: response.data.count,
        next: response.data.next,
        previous: response.data.previous,
      });
    } catch (err) {
      setError('Failed to load orders.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  if (loading) return <div className="p-4">Loading orders...</div>;
  if (error) return <div className="p-4 text-red-500">{error}</div>;
  if (orders.length === 0) return <div className="p-4">No orders found.</div>;

  return (
    <div className="p-4 max-w-4xl mx-auto">
      <h1 className="text-2xl font-semibold mb-4">Your Orders</h1>

      <div className="space-y-4">
        {orders.map(order => (
          <div key={order.id} className="border rounded-lg p-4 shadow-sm">
            <p><strong>Order ID:</strong> {order.id}</p>
            <p><strong>Date:</strong> {new Date(order.created_at).toLocaleString()}</p>
            <p><strong>Status:</strong> {order.status}</p>
            <p><strong>Items:</strong> {order.items.length}</p>
            {/* Optional: Navigate to order detail if implemented */}
            {/* <button onClick={() => navigate(`/orders/${order.id}`)}>View Details</button> */}
          </div>
        ))}
      </div>

      {/* Pagination Controls */}
      <div className="mt-6 flex justify-between">
        <button
          disabled={!pagination.previous}
          onClick={() => fetchOrders(pagination.previous)}
          className={`px-4 py-2 rounded bg-gray-200 hover:bg-gray-300 ${
            !pagination.previous ? 'opacity-50 cursor-not-allowed' : ''
          }`}
        >
          Previous
        </button>
        <button
          disabled={!pagination.next}
          onClick={() => fetchOrders(pagination.next)}
          className={`px-4 py-2 rounded bg-gray-200 hover:bg-gray-300 ${
            !pagination.next ? 'opacity-50 cursor-not-allowed' : ''
          }`}
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default OrdersListPage;
