import { useEffect, useState, useContext } from "react";
import { getCart, setCartQuantity, removeFromCart } from "../api/cartApi";
import { AuthContext } from "../context/AuthContext";

const CartPage = () => {
  const [cart, setCart] = useState(null);
  const [loading, setLoading] = useState(true);
  const { isAuthenticated } = useContext(AuthContext);

  useEffect(() => {
    if (isAuthenticated) {
      fetchCart();
    }
}, [isAuthenticated]);
  const fetchCart = async () => {
    try {
      const res = await getCart(); // returns { items: [...], subtotal: ..., total: ... }
      setCart(res.data);
    } catch (err) {
      console.error("Error loading cart:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleQuantityChange = async (productId, quantity) => {
    if (quantity < 1) return;
    try {
      await setCartQuantity(productId, quantity);
      fetchCart();
    } catch (err) {
      console.error("Error updating quantity:", err);
    }
  };

  const handleRemove = async (productId) => {
    try {
      await removeFromCart(productId);
      fetchCart();
    } catch (err) {
      console.error("Error removing item:", err);
    }
  };

  if (loading) return <p className="text-center mt-10">Loading cart...</p>;
  if (!cart) return <p className="text-center mt-10">Failed to load cart.</p>;

  const { items, subtotal, total } = cart;

  return (
    <div className="p-4 max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Your Cart</h2>

      {items.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <>
          {items.map((item) => (
            <div
              key={item.product.id}
              className="flex justify-between items-center border-b py-2"
            >
              <div>
                <p className="font-semibold">{item.product.title}</p>
                <p>
                  ${Number(item.product.price).toFixed(2)} x {item.quantity}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() =>
                    handleQuantityChange(item.product.id, item.quantity - 1)
                  }
                  disabled={item.quantity === 1}
                >
                  -
                </button>
                <span>{item.quantity}</span>
                <button
                  onClick={() =>
                    handleQuantityChange(item.product.id, item.quantity + 1)
                  }
                >
                  +
                </button>
                <button
                  onClick={() => handleRemove(item.product.id)}
                  className="text-red-500 ml-4"
                >
                  Remove
                </button>
              </div>
            </div>
          ))}

          <div className="mt-6 p-4 bg-gray-100 rounded">
            <p>Subtotal: ${Number(subtotal).toFixed(2)}</p>
            <p>Shipping: $10.00</p>
            <p className="font-bold text-lg">
              Total: ${Number(total).toFixed(2)}
            </p>
          </div>
        </>
      )}
    </div>
  );
};

export default CartPage;
