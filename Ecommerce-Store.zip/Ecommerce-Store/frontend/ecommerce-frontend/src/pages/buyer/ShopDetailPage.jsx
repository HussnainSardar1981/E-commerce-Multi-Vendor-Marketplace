import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "../../axios";

export default function ShopDetailPage() {
   const { id } = useParams();
   const [shop, setShop] = useState(null);
   const [loading, setLoading] = useState(true);

   useEffect(() => {
      axios
         .get(`/api/shops/public/shops/${id}/`)
         .then((res) => setShop(res.data))
         .catch((err) => console.error(err))
         .finally(() => setLoading(false));
   }, [id]);

   if (loading)
      return <div className="p-8 text-center text-lg text-gray-600">Loading shop...</div>;
   if (!shop)
      return (
         <div className="p-8 text-center text-red-500 text-lg">
            Shop not found.
         </div>
      );

   return (
      <div className="max-w-4xl mx-auto px-6 py-10">
         <div className="bg-white shadow rounded-xl p-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">{shop.name}</h1>
            <p className="text-gray-700 text-lg mb-6">
               {shop.description || "No description available."}
            </p>
         </div>
      </div>
   );
}
