import { useParams, Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import axios from '../../axios';

export default function BuyerProductDetailPage() {
   const { id } = useParams();
   const [product, setProduct] = useState(null);
   const [loading, setLoading] = useState(true);
   const baseURL = import.meta.env.VITE_API_BASE_URL;

   useEffect(() => {
      axios.get(`/api/store/products/${id}/`)
         .then(res => setProduct(res.data))
         .catch(err => console.error(err))
         .finally(() => setLoading(false));
   }, [id]);

   if (loading) return <div className="p-4 text-center">Loading...</div>;
   if (!product) return <div className="p-4 text-center text-red-500">Product not found.</div>;

   return (
      <div className="max-w-5xl mx-auto p-6">
         <div className="flex flex-col md:flex-row gap-6">
            <img
               src={product.image}
               alt={product.title}
               className="w-full md:w-1/2 h-auto object-cover rounded-lg shadow"
            />
            <div className="flex-1">
               <h1 className="text-3xl font-bold mb-2">{product.title}</h1>
               <p className="text-primary font-bold text-2xl mb-2">${product.price}</p>
               <p className="text-sm text-gray-600 mb-4">Category: {product.category?.name}</p>
               <p className="mb-4 text-gray-700">{product.description || 'No description available.'}</p>
               <p className="text-sm text-gray-700">Seller: <Link to={`/buyer/shops/${product.shop?.id}`} className="text-blue-600 hover:underline">{product.shop?.name}</Link></p>
            </div>
         </div>
      </div>
   );
}
