import { useEffect, useState } from 'react';
import axios from '../../axios';
import BuyerProductCard from '../../components/BuyerProductCard';

export default function BuyerProductsPage() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get('/api/store/products/')
      .then(res => {
        // if API is paginated, products are in res.data.results
        setProducts(res.data.results || []); 
      })
      .catch(err => console.error(err))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="bg-gray-50 py-10">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold mb-6">Shop All Products</h2>
        {loading ? (
          <p className="text-gray-500">Loading...</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {Array.isArray(products) && products.length > 0 ? (
              products.map(product => (
                <BuyerProductCard key={product.id} product={product} />
              ))
            ) : (
              <p className="text-gray-500">No products found.</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
