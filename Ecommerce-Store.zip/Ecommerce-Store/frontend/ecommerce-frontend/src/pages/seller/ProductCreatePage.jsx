import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "../../axios";
import routes from "../../routes";

const ProductCreatePage = () => {
   const navigate = useNavigate();

   const [formData, setFormData] = useState({
      title: "",
      description: "",
      price: "",
      stock: "",
      category_id: "",   // ✅ FIXED
      tag_ids: [],       // ✅ FIXED
      image: null,
   });

   const [categories, setCategories] = useState([]);
   const [tags, setTags] = useState([]);
   const [loading, setLoading] = useState(false);

   useEffect(() => {
      axios.get("/api/store/categories/").then((res) => {
         setCategories(Array.isArray(res.data) ? res.data : res.data.results || []);
      });
      axios.get("/api/store/tags/").then((res) => {
         setTags(Array.isArray(res.data) ? res.data : res.data.results || []);
      });
   }, []);

   const handleChange = (e) => {
      const { name, value, type } = e.target;
      if (type === "file") {
         setFormData({ ...formData, [name]: e.target.files[0] });
      } else if (type === "select-multiple") {
         const selected = Array.from(e.target.selectedOptions).map((opt) => opt.value);
         setFormData({ ...formData, [name]: selected });
      } else {
         setFormData({ ...formData, [name]: value });
      }
   };

   const handleSubmit = async (e) => {
      e.preventDefault();
      setLoading(true);

      const data = new FormData();
      data.append("title", formData.title);
      data.append("description", formData.description);
      data.append("price", formData.price);
      data.append("stock", formData.stock);
      data.append("category_id", formData.category_id); // ✅ FIXED
      formData.tag_ids.forEach((id) => data.append("tag_ids", id)); // ✅ FIXED
      if (formData.image) {
         data.append("image", formData.image);
      }

      try {
         await axios.post("/api/store/my-products/", data, {
            headers: { "Content-Type": "multipart/form-data" },
         });
         navigate(routes.sellerProducts);
      } catch (error) {
         console.error("Product creation failed", error);
         if (error.response) {
            console.log("Backend response data:", error.response.data);
         }
      } finally {
         setLoading(false);
      }
   };

   return (
      <section className="py-10 bg-white">
         <div className="max-w-2xl mx-auto px-4">
            <h2 className="text-2xl font-bold mb-6">Add New Product</h2>

            <form onSubmit={handleSubmit} className="space-y-4">
               <div>
                  <label className="block mb-1 font-medium">Title</label>
                  <input
                     type="text"
                     name="title"
                     required
                     className="w-full border px-3 py-2 rounded"
                     value={formData.title}
                     onChange={handleChange}
                  />
               </div>

               <div>
                  <label className="block mb-1 font-medium">Description</label>
                  <textarea
                     name="description"
                     required
                     rows={4}
                     className="w-full border px-3 py-2 rounded"
                     value={formData.description}
                     onChange={handleChange}
                  />
               </div>

               <div className="flex gap-4">
                  <div className="flex-1">
                     <label className="block mb-1 font-medium">Price ($)</label>
                     <input
                        type="number"
                        name="price"
                        required
                        step="0.01"
                        className="w-full border px-3 py-2 rounded"
                        value={formData.price}
                        onChange={handleChange}
                     />
                  </div>
                  <div className="flex-1">
                     <label className="block mb-1 font-medium">Stock</label>
                     <input
                        type="number"
                        name="stock"
                        required
                        className="w-full border px-3 py-2 rounded"
                        value={formData.stock}
                        onChange={handleChange}
                     />
                  </div>
               </div>

               <div>
                  <label className="block mb-1 font-medium">Category</label>
                  <select
                     name="category_id" // ✅ FIXED
                     required
                     className="w-full border px-3 py-2 rounded"
                     value={formData.category_id}
                     onChange={handleChange}
                  >
                     <option value="">Select category</option>
                     {categories.map((cat) => (
                        <option key={cat.id} value={cat.id}>
                           {cat.name}
                        </option>
                     ))}
                  </select>
               </div>

               <div>
                  <label className="block mb-1 font-medium">Tags</label>
                  <select
                     name="tag_ids" // ✅ FIXED
                     multiple
                     className="w-full border px-3 py-2 rounded h-32"
                     value={formData.tag_ids}
                     onChange={handleChange}
                  >
                     {tags.map((tag) => (
                        <option key={tag.id} value={tag.id}>
                           {tag.name}
                        </option>
                     ))}
                  </select>
                  <small className="text-gray-500">Hold Ctrl or Cmd to select multiple.</small>
               </div>

               <div>
                  <label className="block mb-1 font-medium">Product Image</label>
                  <input
                     type="file"
                     name="image"
                     accept="image/*"
                     className="w-full border px-3 py-2 rounded"
                     onChange={handleChange}
                  />
               </div>

               <div>
                  <button
                     type="submit"
                     disabled={loading}
                     className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                  >
                     {loading ? "Creating..." : "Create Product"}
                  </button>
               </div>
            </form>
         </div>
      </section>
   );
};

export default ProductCreatePage;
