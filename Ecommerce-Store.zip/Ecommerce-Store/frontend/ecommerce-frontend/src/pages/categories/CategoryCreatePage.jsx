import { useState } from "react";
import axios from "../../axios";
import { useNavigate } from "react-router-dom";
import routes from "../../routes";


const CategoryCreatePage = () => {
   const [name, setName] = useState("");
   const [error, setError] = useState("");
   const navigate = useNavigate();

   const handleSubmit = async (e) => {
      e.preventDefault();
      setError("");

      try {
         await axios.post("/api/store/categories/", { name });
         alert("Category created successfully!");
         navigate(routes.sellerProducts);
      } catch (err) {
         setError(err.response?.data?.detail || "Failed to create category");
      }
   };

   return (
      <div className="max-w-md mx-auto mt-10 p-6 bg-white shadow rounded">
         <h2 className="text-xl font-bold mb-4">Create New Category</h2>
         <form onSubmit={handleSubmit}>
            <label className="block mb-2">
               Category Name:
               <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2 border mt-1 rounded"
                  required
               />
            </label>
            {error && <p className="text-red-500 mb-2">{error}</p>}
            <button
               type="submit"
               className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
            >
               Create
            </button>
         </form>
      </div>
   );
};

export default CategoryCreatePage;
