import { useState } from "react";
import axios from "../../axios";
import { useNavigate } from "react-router-dom";
import routes from "../../routes";

const TagCreatePage = () => {
   const [name, setName] = useState("");
   const [loading, setLoading] = useState(false);
   const navigate = useNavigate();

   const handleSubmit = async (e) => {
      e.preventDefault();
      setLoading(true);
      try {
         await axios.post("/api/store/tags/", { name });
         alert("Tag created!");
         navigate(routes.sellerProducts); // If you have a tags list page, or navigate anywhere
      } catch (error) {
         alert(
            "Failed to create tag: " +
            (error.response?.data?.name || JSON.stringify(error.response?.data))
         );
      } finally {
         setLoading(false);
      }
   };

   return (
      <section className="py-10 bg-white">
         <div className="max-w-md mx-auto px-4">
            <h2 className="text-2xl font-bold mb-6">Add New Tag</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
               <div>
                  <label className="block mb-1 font-medium">Tag Name</label>
                  <input
                     type="text"
                     name="name"
                     required
                     className="w-full border px-3 py-2 rounded"
                     value={name}
                     onChange={(e) => setName(e.target.value)}
                  />
               </div>
               <div>
                  <button
                     type="submit"
                     disabled={loading}
                     className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                  >
                     {loading ? "Creating..." : "Create Tag"}
                  </button>
               </div>
            </form>
         </div>
      </section>
   );
};

export default TagCreatePage;
