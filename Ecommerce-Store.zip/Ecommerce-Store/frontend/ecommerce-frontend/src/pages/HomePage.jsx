const HomePage = () => {
  return (
    <section className="relative bg-white py-16 lg:py-28">
      <div className="container mx-auto px-4">
        <div className="flex flex-col-reverse items-center justify-between gap-8 lg:flex-row">
          {/* Text */}
          <div className="max-w-xl text-center lg:text-left">
            <h1 className="text-4xl font-bold leading-tight text-gray-900 sm:text-5xl lg:text-6xl">
              Discover Premium Products
            </h1>
            <p className="mt-6 text-lg text-gray-600">
              Browse our collection of top-quality items and enjoy seamless shopping.
            </p>
            <a
              href="/products"
              className="mt-8 inline-block rounded-lg bg-blue-600 px-8 py-3 text-white text-lg font-medium hover:bg-blue-700 transition"
            >
              Shop Now
            </a>
          </div>

        </div>
      </div>
    </section>
  );
};

export default HomePage;
