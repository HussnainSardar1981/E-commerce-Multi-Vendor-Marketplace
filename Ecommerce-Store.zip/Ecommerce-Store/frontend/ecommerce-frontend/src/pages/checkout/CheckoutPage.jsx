import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import routes from "../../routes";
import { getCart } from "../../api/cartApi";
import axios from "../../axios";

export default function CheckoutPage() {
  const navigate = useNavigate();
  const [cart, setCart] = useState(null);
  const [loading, setLoading] = useState(true);
  const [shippingAddress, setShippingAddress] = useState("");
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    fetchCart();
  }, []);

  const fetchCart = async () => {
    try {
      setLoading(true);
      const response = await getCart();
      setCart(response.data);

      if (!response.data || !response.data.items?.length) {
        setError("Your cart is empty. Please add items before checkout.");
      }
    } catch (err) {
      console.error("Failed to fetch cart:", err);
      setError("Failed to load cart. Please try again.");
      setCart(null);
    } finally {
      setLoading(false);
    }
  };

  const validateForm = () => {
    if (!shippingAddress.trim()) {
      setError("Please provide a shipping address.");
      return false;
    }
    if (shippingAddress.trim().length < 10) {
      setError("Please provide a complete shipping address (minimum 10 characters).");
      return false;
    }
    if (!cart || !cart.items?.length) {
      setError("Your cart is empty.");
      return false;
    }
    return true;
  };

  const handleCheckout = async (e) => {
    e.preventDefault();
    setError("");

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      const subtotal = cart.items.reduce(
        (sum, item) => sum + item.quantity * item.product.price,
        0
      );
      const shipping = 0; // Dynamic shipping can be added later
      const total = subtotal + shipping;

      const payload = {
        shipping_address: shippingAddress.trim(),
        subtotal: subtotal.toFixed(2),
        shipping: shipping.toFixed(2),
        total: total.toFixed(2),
      };

      console.log("Checkout payload:", payload);

      const response = await axios.post("/api/payments/create-checkout-session/", payload, {
        headers: { "Content-Type": "application/json" },
      });

      if (response.data.url) {
        // Store checkout data for success page
        sessionStorage.setItem(
          "checkoutData",
          JSON.stringify({
            shipping_address: shippingAddress.trim(),
            total: total.toFixed(2),
            items: cart.items.map((item) => ({
              product: item.product.title,
              quantity: item.quantity,
              price: item.product.price,
            })),
          })
        );

        // Redirect to Stripe
        window.location.href = response.data.url;
      } else {
        throw new Error("No checkout URL received from server");
      }
    } catch (err) {
      console.error("Stripe checkout error:", err);
      setError(
        err.response?.data?.error ||
        err.response?.data?.detail ||
        "Failed to initiate checkout. Please try again."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your cart...</p>
        </div>
      </div>
    );
  }

  if (!cart || !cart.items?.length) {
    return (
      <div className="p-6 max-w-2xl mx-auto bg-white shadow rounded-lg text-center">
        <div className="py-8">
          <svg
            className="mx-auto h-12 w-12 text-gray-400 mb-4"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-2.5 5M7 13l2.5 5m6-5L17 8m0 0V6a2 2 0 00-2-2H9a2 2 0 00-2 2v2m8 0V8"
            />
          </svg>
          <h2 className="text-xl font-semibold text-gray-700 mb-2">Your cart is empty</h2>
          <p className="text-gray-500 mb-4">Add some items to your cart before proceeding to checkout.</p>
          <button
            onClick={() => navigate(routes.products || "/products")}
            className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 transition duration-200"
          >
            Continue Shopping
          </button>
        </div>
      </div>
    );
  }

  const subtotal = cart.items.reduce(
    (sum, item) => sum + item.quantity * item.product.price,
    0
  );
  const shipping = 0;
  const total = subtotal + shipping;

  return (
    <div className="p-6 max-w-2xl mx-auto bg-white shadow rounded-lg">
      <h2 className="text-3xl font-semibold mb-6 text-gray-800">Checkout</h2>

      {error && (
        <div className="mb-4 p-4 bg-red-100 border border-red-300 text-red-700 rounded-lg">
          <div className="flex items-center">
            <svg
              className="h-5 w-5 mr-2"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path
                fillRule="evenodd"
                d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                clipRule="evenodd"
              />
            </svg>
            {error}
          </div>
        </div>
      )}

      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-700 mb-4">Order Summary</h3>
        <div className="bg-gray-50 rounded-lg p-4">
          <ul className="divide-y divide-gray-200 mb-4">
            {cart.items.map((item) => (
              <li
                key={`${item.product.id}-${item.id}`}
                className="py-3 flex justify-between items-center"
              >
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900">{item.product.title}</h4>
                  <p className="text-sm text-gray-500">Qty: {item.quantity}</p>
                  <p className="text-sm text-gray-500">₹{item.product.price} each</p>
                </div>
                <span className="font-medium text-gray-900">
                  ₹{(item.product.price * item.quantity).toFixed(2)}
                </span>
              </li>
            ))}
          </ul>
          <div className="border-t border-gray-200 pt-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span>Subtotal:</span>
              <span>₹{subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Shipping:</span>
              <span>₹{shipping.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-lg font-semibold border-t border-gray-200 pt-2">
              <span>Total:</span>
              <span>₹{total.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      <form onSubmit={handleCheckout} className="space-y-4">
        <div>
          <label
            htmlFor="shippingAddress"
            className="block text-sm font-medium text-gray-700 mb-2"
          >
            Shipping Address *
          </label>
          <textarea
            id="shippingAddress"
            rows="4"
            className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
            placeholder="Enter your complete shipping address (street, city, state, postal code)"
            value={shippingAddress}
            onChange={(e) => setShippingAddress(e.target.value)}
            disabled={isSubmitting}
            required
          />
          <p className="text-xs text-gray-500 mt-1">
            Provide a complete address for delivery
          </p>
        </div>

        <button
          type="submit"
          disabled={isSubmitting || !cart?.items?.length}
          className={`w-full py-4 px-6 rounded-lg font-medium text-white transition duration-200 ${isSubmitting || !cart?.items?.length
            ? "bg-gray-400 cursor-not-allowed"
            : "bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:ring-blue-200"
            }`}
        >
          {isSubmitting ? (
            <div className="flex items-center justify-center">
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
              Redirecting to Payment...
            </div>
          ) : (
            `Proceed to Payment - ₹${total.toFixed(2)}`
          )}
        </button>
      </form>

      <div className="mt-4 text-center">
        <p className="text-xs text-gray-500">
          You will be redirected to Stripe for secure payment processing
        </p>
      </div>
    </div>
  );
}