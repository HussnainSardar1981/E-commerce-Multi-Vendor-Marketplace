import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from '../../axios';
import routes from '../../routes';

const ShopEditPage = () => {
  const [shop, setShop] = useState(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [logo, setLogo] = useState(null);
  const [preview, setPreview] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  // 🛰️ Load current shop details
  useEffect(() => {
    axios
      .get('/api/shops/my-shop/')
      .then((res) => {
        setShop(res.data);
        setName(res.data.name);
        setDescription(res.data.description);
        setPreview(res.data.logo);
      })
      .catch(() => {
        setError('Could not load shop. Make sure you have one.');
      });
  }, []);

  // 🧨 Submit updated shop data
  const handleUpdate = async (e) => {
    e.preventDefault();
    setMessage('');
    setError('');

    const formData = new FormData();
    formData.append('name', name);
    formData.append('description', description);
    if (logo) formData.append('logo', logo);

    try {
      const res = await axios.put('/api/shops/my-shop/', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      setMessage('Shop updated successfully.');
      setPreview(res.data.logo); // update preview
    } catch (err) {
      setError('Failed to update shop. ' + (err.response?.data?.detail || ''));
    }
  };

  if (!shop) {
    return (
      <div className="max-w-2xl mx-auto mt-10 text-center text-red-600">
        {error || 'Loading...'}
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto mt-10 p-6 bg-white shadow-md rounded-lg">
      <h2 className="text-2xl font-bold mb-4">Edit Shop</h2>

      {message && <p className="text-green-600 mb-3">{message}</p>}
      {error && <p className="text-red-600 mb-3">{error}</p>}

      <form onSubmit={handleUpdate} className="space-y-4">
        <div>
          <label className="block font-medium">Shop Name</label>
          <input
            type="text"
            className="w-full border px-3 py-2 rounded"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>

        <div>
          <label className="block font-medium">Description</label>
          <textarea
            className="w-full border px-3 py-2 rounded"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={4}
          />
        </div>

        <div>
          <label className="block font-medium">Shop Logo</label>
          <input
            type="file"
            onChange={(e) => {
              setLogo(e.target.files[0]);
              setPreview(URL.createObjectURL(e.target.files[0]));
            }}
            accept="image/*"
          />
        </div>

        {preview && (
          <div className="mt-4">
            <p className="font-medium mb-1">Logo Preview:</p>
            <img
              src={preview}
              alt="Shop Logo"
              className="w-32 h-32 object-cover border rounded"
            />
          </div>
        )}

        <div className="flex gap-4 mt-6">
          <button
            type="submit"
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded"
          >
            Save Changes
          </button>
          <button
            type="button"
            onClick={() => navigate(routes.shopDashboard)}
            className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded"
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
};

export default ShopEditPage;
