import { useEffect, useState } from 'react';
import axios from '../../axios';

const ShopDashboard = () => {
   const [shop, setShop] = useState(null);
   const [name, setName] = useState('');
   const [description, setDescription] = useState('');
   const [logo, setLogo] = useState(null);
   const [message, setMessage] = useState('');
   const [stripeLoading, setStripeLoading] = useState(false);
   const [stripeError, setStripeError] = useState(null);

   useEffect(() => {
      axios.get('/api/shops/my-shop/')
         .then(res => {
            setShop(res.data);
            setName(res.data.name);
            setDescription(res.data.description);
         })
         .catch(() => {
            setShop(null);
         });
   }, []);

   const handleUpdate = async (e) => {
      e.preventDefault();
      setMessage('');

      const formData = new FormData();
      formData.append('name', name);
      formData.append('description', description);
      if (logo) formData.append('logo', logo);

      try {
         const res = await axios.put('/api/shops/my-shop/', formData, {
            headers: {
               'Content-Type': 'multipart/form-data',
            },
         });
         setShop(res.data);
         setMessage('Shop updated successfully.');
      } catch (err) {
         setMessage('Update failed.');
      }
   };

   const handleStripeConnect = async () => {
      setStripeLoading(true);
      setStripeError(null);
      try {
         const res = await axios.post('/api/payments/connect/');
         window.location.href = res.data.url; // Redirect to Stripe onboarding
      } catch (err) {
         setStripeError('Failed to connect to Stripe. Try again.');
         console.error(err);
      } finally {
         setStripeLoading(false);
      }
   };

   if (!shop) return <div className="p-6">You don't have a shop yet.</div>;

   return (
      <div className="max-w-2xl mx-auto mt-8 p-6 bg-white shadow rounded">
         <h2 className="text-2xl font-semibold mb-4">My Shop</h2>
         {message && <div className="text-green-600 mb-2">{message}</div>}
         <form onSubmit={handleUpdate} className="space-y-4">
            <input
               type="text"
               value={name}
               onChange={(e) => setName(e.target.value)}
               className="w-full p-2 border rounded"
            />
            <textarea
               value={description}
               onChange={(e) => setDescription(e.target.value)}
               className="w-full p-2 border rounded"
            />
            <input
               type="file"
               onChange={(e) => setLogo(e.target.files[0])}
               className="w-full"
               accept="image/*"
            />
            <button type="submit" className="bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700">
               Update Shop
            </button>
         </form>

         {shop.logo && (
            <div className="mt-4">
               <h4 className="font-semibold mb-1">Current Logo:</h4>
               <img src={shop.logo} alt="Shop Logo" className="w-32 h-32 object-cover border rounded" />
            </div>
         )}

         {/* Stripe Connect Section */}
         <div className="mt-8">
            <h3 className="text-xl font-semibold mb-2">Stripe Payouts</h3>
            <p className="mb-4 text-gray-600">To receive payments, connect your Stripe account.</p>
            <button
               onClick={handleStripeConnect}
               disabled={stripeLoading}
               className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700"
            >
               {stripeLoading ? 'Redirecting to Stripe...' : 'Connect Stripe'}
            </button>
            {stripeError && <p className="text-red-600 mt-2">{stripeError}</p>}
         </div>
      </div>
   );
};

export default ShopDashboard;
