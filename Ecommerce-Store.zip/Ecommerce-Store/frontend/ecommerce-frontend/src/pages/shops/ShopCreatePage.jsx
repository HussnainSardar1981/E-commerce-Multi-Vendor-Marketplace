import { useState } from 'react';
import axios from '../../axios';
import { useNavigate } from 'react-router-dom';

const ShopCreatePage = () => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [logo, setLogo] = useState(null);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    const formData = new FormData();
    formData.append('name', name);
    formData.append('description', description);
    if (logo) formData.append('logo', logo);

    try {
      await axios.post('/shops/create/', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      navigate('/shop/dashboard');
    } catch (err) {
      setError(err.response?.data?.detail || 'Error creating shop.');
    }
  };

  return (
    <div className="max-w-xl mx-auto mt-8 p-6 bg-white shadow rounded">
      <h2 className="text-2xl font-semibold mb-4">Create Your Shop</h2>
      {error && <div className="text-red-500 mb-2">{error}</div>}
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          placeholder="Shop Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full p-2 border rounded"
          required
        />
        <textarea
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full p-2 border rounded"
        />
        <input
          type="file"
          onChange={(e) => setLogo(e.target.files[0])}
          className="w-full"
          accept="image/*"
        />
        <button type="submit" className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700">
          Create Shop
        </button>
      </form>
    </div>
  );
};

export default ShopCreatePage;
