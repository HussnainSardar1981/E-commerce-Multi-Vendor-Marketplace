import { useState } from "react";
import axios from "../axios";
import routes from "../routes";
import { useNavigate } from "react-router-dom";
import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";

export default function RegisterPage() {
  const [formData, setFormData] = useState({
    email: "",
    name: "",
    password: "",
    is_seller: false,
  });

  const navigate = useNavigate();
  const { login } = useContext(AuthContext); // ✅ Use context login

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      // 1️⃣ Register user
      await axios.post("/api/accounts/register/", formData);

      // 2️⃣ Auto-login
      const res = await axios.post("/api/accounts/login/", {
        email: formData.email,
        password: formData.password,
      });

      // 3️⃣ Update global auth state
      login(res.data.user, res.data.access, res.data.refresh);

      // 4️⃣ Redirect
      navigate(routes.home);
    } catch (err) {
      console.error("Registration failed:", err.response?.data || err.message);
      alert("Registration failed.");
    }
  };

  return (
    <form onSubmit={handleRegister} className="space-y-4 max-w-md mx-auto p-4">
      <h2 className="text-xl font-bold">Register</h2>

      <input
        name="email"
        type="email"
        placeholder="Email"
        onChange={handleChange}
        value={formData.email}
        required
        className="w-full border px-3 py-2 rounded"
      />

      <input
        name="name"
        type="text"
        placeholder="Name"
        onChange={handleChange}
        value={formData.name}
        required
        className="w-full border px-3 py-2 rounded"
      />

      <input
        name="password"
        type="password"
        placeholder="Password"
        onChange={handleChange}
        value={formData.password}
        required
        className="w-full border px-3 py-2 rounded"
      />

      <label className="flex items-center space-x-2">
        <input
          type="checkbox"
          name="is_seller"
          checked={formData.is_seller}
          onChange={handleChange}
        />
        <span>Register as Seller</span>
      </label>

      <button
        type="submit"
        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
      >
        Register
      </button>
    </form>
  );
}
