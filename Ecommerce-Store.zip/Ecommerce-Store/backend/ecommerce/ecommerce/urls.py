from django.contrib import admin
from django.urls import path, include
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),

    # JWT auth routes
    path('api/accounts/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/accounts/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),

    # Your app routes
    path('api/accounts/', include('accounts.urls')),  # custom registration/login views
    path('api/store/', include('store.urls')), # store app routes
    path('api/orders/', include('orders.urls')), # orders app routes
    path('api/shops/', include('shops.urls')), # shops app routes
    path("api/payments/", include("payments.urls")), # payments app routes
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)