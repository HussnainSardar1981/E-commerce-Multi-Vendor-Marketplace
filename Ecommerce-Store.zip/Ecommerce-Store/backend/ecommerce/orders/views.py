from rest_framework import viewsets, permissions, status
from .models import Order, OrderItem, Cart, CartItem
from store.models import Product
from .serializers import OrderSerializer, CartSerializer, CartItemSerializer
from rest_framework.response import Response
from rest_framework.decorators import action
from django.shortcuts import get_object_or_404


class OrderViewSet(viewsets.ModelViewSet):
    serializer_class = OrderSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Order.objects.filter(user=self.request.user).order_by('-created_at')

class CartViewSet(viewsets.ViewSet):
    def get_cart(self, request):
        """Returns a cart from session (if anonymous) or DB (if logged in)."""
        if request.user.is_authenticated:
            cart, _ = Cart.objects.get_or_create(user=request.user)
            return cart
        else:
            session_cart = request.session.get('cart', {})
            return session_cart

    def list(self, request):
        if request.user.is_authenticated:
            cart = self.get_cart(request)
            serializer = CartSerializer(cart)
            return Response(serializer.data)
        else:
            session_cart = self.get_cart(request)

            items = []
            for product_id, quantity in session_cart.items():
                try:
                    product = Product.objects.get(id=product_id)
                    items.append({
                        'product': {
                            'id': product.id,
                            'title': product.title,
                            'price': product.price,
                            'image': product.image.url if product.image else None
                        },
                        'quantity': quantity
                    })
                except Product.DoesNotExist:
                    continue
            return Response({'items': items})

    @action(detail=False, methods=['post'])
    def add(self, request):
        product_id = request.data.get('product_id')
        quantity = int(request.data.get('quantity', 1))
        product = get_object_or_404(Product, id=product_id)

        if request.user.is_authenticated:
            cart = self.get_cart(request)
            item, created = CartItem.objects.get_or_create(cart=cart, product=product)
            item.quantity += quantity
            item.save()
        else:
            cart = request.session.get('cart', {})
            cart[str(product_id)] = cart.get(str(product_id), 0) + quantity
            request.session['cart'] = cart
            request.session.modified = True

        return Response({'message': 'Item added to cart'}, status=status.HTTP_200_OK)

    @action(detail=False, methods=['post'])
    def remove(self, request):
        product_id = request.data.get('product_id')

        if request.user.is_authenticated:
            cart = self.get_cart(request)
            CartItem.objects.filter(cart=cart, product__id=product_id).delete()
        else:
            cart = request.session.get('cart', {})
            if str(product_id) in cart:
                del cart[str(product_id)]
                request.session['cart'] = cart
                request.session.modified = True

        return Response({'message': 'Item removed from cart'}, status=status.HTTP_200_OK)
    
    @action(detail=False, methods=['post'], permission_classes=[permissions.IsAuthenticated])
    def checkout(self, request):
        cart = self.get_cart(request)
        if not cart.items.exists():
            return Response({'error': 'Cart is empty'}, status=status.HTTP_400_BAD_REQUEST)

        # Calculate totals
        subtotal = sum(item.product.price * item.quantity for item in cart.items.all())
        shipping = 10  # Flat rate, or dynamic later
        total = subtotal + shipping

        # Create Order with total fields
        order = Order.objects.create(
            user=request.user,
            subtotal=subtotal,
            shipping=shipping,
            total=total
        )

        # Create OrderItems with price snapshot
        for item in cart.items.all():
            OrderItem.objects.create(
                order=order,
                product=item.product,
                quantity=item.quantity,
                price=item.product.price  # snapshot at time of order
            )

        cart.items.all().delete()  # Clear cart

        return Response({
            'message': f'Order #{order.id} created',
            'subtotal': subtotal,
            'shipping': shipping,
            'total': total
        }, status=status.HTTP_201_CREATED)



    @action(detail=False, methods=['post'])
    def set_quantity(self, request):
        """POST /api/cart/set_quantity/ {product_id, quantity} — Sets exact quantity (replaces)"""
        product_id = request.data.get('product_id')
        quantity = int(request.data.get('quantity', 1))
        product = get_object_or_404(Product, id=product_id)

        if quantity < 1:
            return Response({'error': 'Quantity must be at least 1'}, status=status.HTTP_400_BAD_REQUEST)

        if request.user.is_authenticated:
            cart = self.get_cart(request)
            item, created = CartItem.objects.get_or_create(cart=cart, product=product)
            item.quantity = quantity
            item.save()
        else:
            cart = request.session.get('cart', {})
            cart[str(product_id)] = quantity  # 👈 exact overwrite
            request.session['cart'] = cart
            request.session.modified = True

        return Response({'message': 'Cart quantity updated'}, status=status.HTTP_200_OK)
