from rest_framework.routers import DefaultRouter
from .views import (
    PublicProductViewSet,
    SellerProductViewSet,
    CategoryViewSet,
    TagViewSet,
)

router = DefaultRouter()
router.register(r'products', PublicProductViewSet, basename='public-products')  # for buyers
router.register(r'my-products', SellerProductViewSet, basename='seller-products')  # for sellers
router.register(r'categories', CategoryViewSet)
router.register(r'tags', TagViewSet)

urlpatterns = router.urls
