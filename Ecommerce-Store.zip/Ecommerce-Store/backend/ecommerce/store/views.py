from rest_framework import viewsets, filters, permissions
from .models import Product, Category, Tag
from .serializers import ProductSerializer, CategorySerializer, TagSerializer
from rest_framework import viewsets, filters
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import PermissionDenied


class PublicProductViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Product.objects.all().order_by('-created_at')
    serializer_class = ProductSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ['category', 'tags']
    search_fields = ['title', 'description', 'category__name', 'tags__name']
    permission_classes = [permissions.AllowAny]  # ✅ anyone can access

class SellerProductViewSet(viewsets.ModelViewSet):
    serializer_class = ProductSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ['category', 'tags']
    search_fields = ['title', 'description', 'category__name', 'tags__name']

    def get_queryset(self):
        user = self.request.user
        if user.is_superuser:
            return Product.objects.all().order_by('-created_at')
        return Product.objects.filter(shop=user.shop).order_by('-created_at')

    def perform_create(self, serializer):
        serializer.save()  # shop is already set in serializer.create()



class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [IsAuthenticated]  # restrict to authenticated users

    def perform_create(self, serializer):
        user = self.request.user
        if not user.is_seller:
            raise PermissionDenied("Only sellers can create categories.")
        serializer.save()

class TagViewSet(viewsets.ModelViewSet):
    queryset = Tag.objects.all()
    serializer_class = TagSerializer
