from rest_framework import serializers
from .models import Product, Category, Tag
from django.utils.text import slugify
from shops.models import Shop

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'name', 'slug']
        extra_kwargs = {'slug': {'required': False}}

    def validate(self, data):
        if 'slug' not in data or not data['slug']:
            data['slug'] = slugify(data['name'])
        return data

class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tag
        fields = ['id', 'name']

class ShopSummarySerializer(serializers.ModelSerializer):
    class Meta:
        model = Shop
        fields = ['id', 'name']

class ProductSerializer(serializers.ModelSerializer):
    category = CategorySerializer(read_only=True)
    category_id = serializers.PrimaryKeyRelatedField(
        queryset=Category.objects.all(), source='category', write_only=True
    )
    tags = TagSerializer(read_only=True, many=True)
    tag_ids = serializers.PrimaryKeyRelatedField(
        many=True, queryset=Tag.objects.all(), source='tags', write_only=True
    )
    shop = ShopSummarySerializer(read_only=True) 

    class Meta:
        model = Product
        fields = [
            'id', 'title', 'description', 'price', 'image', 'created_at',
            'category', 'category_id', 'tags', 'tag_ids', 'shop'
        ]
        read_only_fields = ['id', 'created_at']

    def create(self, validated_data):
        user = self.context['request'].user
        validated_data['shop'] = user.shop 
        return super().create(validated_data)