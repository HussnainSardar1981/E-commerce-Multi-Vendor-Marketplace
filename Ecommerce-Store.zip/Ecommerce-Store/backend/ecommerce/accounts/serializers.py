from rest_framework import serializers
from .models import User
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
from shops.models import Shop

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=8, max_length=128)
    is_seller = serializers.BooleanField(default=False) 

    class Meta:
        model = User
        fields = ['email', 'name', 'password', 'is_seller'] 

    def create(self, validated_data):
        is_seller = validated_data.pop('is_seller', False)
        user = User.objects.create_user(
            email=validated_data['email'],
            name=validated_data['name'],
            password=validated_data['password']
        )
        user.is_seller = is_seller
        user.save()

        if is_seller:
            Shop.objects.create(
                owner=user,
                name=f"{user.name}'s Shop",  # Default shop name
                description="",
            )

        return user
      
class LoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True, min_length=8, max_length=128)

    def validate(self, data):
        user = authenticate(
            request=self.context.get('request'),
            email=data['email'],
            password=data['password']
        )
        if not user:
            raise serializers.ValidationError("Unable to log in with provided credentials")
        
        refresh = RefreshToken.for_user(user)
        data['user'] = user
        data['refresh'] = str(refresh)
        data['access'] = str(refresh.access_token)
        return data

      
class UserSerializer(serializers.ModelSerializer):
   class Meta:
      model = User
      fields = ['id', 'email', 'name', 'is_seller']