from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from .serializers import RegisterSerializer, LoginSerializer, UserSerializer
from orders.models import Cart, CartItem
from store.models import Product

class RegisterView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'message': 'User registered successfully'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class LoginView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            user = serializer.validated_data['user']  # now a real User instance

            self.merge_session_cart(request, user)

            return Response({
                'message': 'Login Successfully',
                'user': UserSerializer(user).data,
                'access': serializer.validated_data['access'],
                'refresh': serializer.validated_data['refresh'],
            }, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def merge_session_cart(self, request, user):
        session_cart = request.session.get('cart', {})
        if not session_cart:
            return

        cart, _ = Cart.objects.get_or_create(user=user)
        for product_id, quantity in session_cart.items():
            try:
                product = Product.objects.get(id=product_id)
                item, created = CartItem.objects.get_or_create(cart=cart, product=product)
                item.quantity += quantity
                item.save()
            except Product.DoesNotExist:
                continue

        request.session['cart'] = {}
        request.session.modified = True

class UserProfileView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        serializer = UserSerializer(request.user)
        return Response(serializer.data, status=status.HTTP_200_OK)
