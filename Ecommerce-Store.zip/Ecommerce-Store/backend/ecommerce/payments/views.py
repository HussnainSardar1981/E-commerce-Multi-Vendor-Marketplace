import stripe
import json
import logging
from decimal import Decimal

from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.http import JsonResponse, HttpResponse
from django.shortcuts import get_object_or_404
from django.contrib.auth import get_user_model

from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated

from orders.models import Order, OrderItem, Cart
from .models import Payment

# Setup
logger = logging.getLogger(__name__)
stripe.api_key = settings.STRIPE_SECRET_KEY
User = get_user_model()

# ----------------------------------------------------
# ✅ Create Stripe Checkout Session from Cart
# ----------------------------------------------------
@api_view(["POST"])
@permission_classes([IsAuthenticated])
def create_checkout_session(request):
    user = request.user
    shipping_address = request.data.get("shipping_address", "").strip()

    if not shipping_address:
        return JsonResponse({"error": "Shipping address is required"}, status=400)

    # Fetch cart
    cart = get_object_or_404(Cart, user=user)
    cart_items = cart.items.select_related("product")

    if not cart_items.exists():
        return JsonResponse({"error": "Cart is empty"}, status=400)

    # Build Stripe line_items
    line_items = []
    subtotal = 0

    for item in cart_items:
        product = item.product
        amount = int(product.price * 100)  # in paise
        subtotal += item.quantity * product.price

        line_items.append({
            "price_data": {
                "currency": "inr",
                "product_data": {
                    "name": product.title,
                },
                "unit_amount": amount,
            },
            "quantity": item.quantity,
        })

    shipping = 0  # Static for now
    total = subtotal + shipping

    # Pass necessary metadata to webhook
    metadata = {
        "user_id": str(user.id),
        "user_email": user.email,
        "subtotal": str(subtotal),
        "shipping": str(shipping),
        "total": str(total),
        "shipping_address": shipping_address,
    }

    try:
        session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            line_items=line_items,
            mode="payment",
            success_url=f"{settings.STRIPE_SUCCESS_URL}?session_id={{CHECKOUT_SESSION_ID}}",
            cancel_url=settings.STRIPE_CANCEL_URL,
            metadata=metadata,
        )
        return JsonResponse({"url": session.url})

    except Exception as e:
        logger.error("❌ Stripe session creation failed", exc_info=True)
        return JsonResponse({"error": str(e)}, status=500)

# ----------------------------------------------------
# ✅ Stripe Webhook Handler (Creates Order)
# ----------------------------------------------------
@csrf_exempt
@require_POST
def stripe_webhook(request):
    logger.info("🔥 Stripe webhook received")
    payload = request.body
    sig_header = request.META.get("HTTP_STRIPE_SIGNATURE")
    endpoint_secret = settings.STRIPE_WEBHOOK_SECRET

    if not sig_header:
        logger.warning("❌ Stripe signature missing")
        return HttpResponse("Missing signature", status=400)

    try:
        event = stripe.Webhook.construct_event(payload, sig_header, endpoint_secret)
    except ValueError as e:
        logger.error(f"❌ Invalid payload: {e}")
        return HttpResponse("Invalid payload", status=400)
    except stripe.error.SignatureVerificationError as e:
        logger.error(f"❌ Invalid signature: {e}")
        return HttpResponse("Invalid signature", status=400)

    if event['type'] == 'checkout.session.completed':
        session = event['data']['object']
        metadata = session.get("metadata", {})
        session_id = session.get("id")

        logger.info(f"🎯 Processing checkout session: {session_id}")

        try:
            user_id = metadata.get("user_id")
            user_email = metadata.get("user_email")
            subtotal = Decimal(metadata.get("subtotal", "0"))
            shipping = Decimal(metadata.get("shipping", "0"))
            total = Decimal(metadata.get("total", "0"))
            shipping_address = metadata.get("shipping_address", "")

            if not user_id:
                logger.error("❌ user_id missing in session metadata")
                return HttpResponse("Missing user_id", status=400)

            # Prevent duplicate order
            if Order.objects.filter(stripe_session_id=session_id).exists():
                logger.warning(f"⚠️ Order already exists for session {session_id}")
                return HttpResponse("Order already exists", status=200)

            # Get user and cart
            user = User.objects.get(id=user_id)
            cart = Cart.objects.get(user=user)
            cart_items = cart.items.select_related("product")

            if not cart_items.exists():
                logger.warning("❌ Cart is empty at webhook time")
                return HttpResponse("Cart is empty", status=400)

            # Create Order with all required fields, including email
            order = Order.objects.create(
                user=user,
                email=user_email,  # Store the email from metadata
                subtotal=subtotal,
                shipping=shipping,
                total=total,
                shipping_address=shipping_address,
                status="paid",
                payment_method="stripe",
                stripe_session_id=session_id,
            )

            # Create Order Items
            order_items = []
            for item in cart_items:
                order_items.append(OrderItem(
                    order=order,
                    product=item.product,
                    quantity=item.quantity,
                    price=item.product.price,
                ))
            OrderItem.objects.bulk_create(order_items)

            # Create Payment record
            payment_intent = session.get("payment_intent", "")
            Payment.objects.create(
                order=order,
                stripe_payment_intent=payment_intent,
                amount_received=total,
                currency="inr",
                payment_status="completed",
            )

            # Clear cart
            cart.items.all().delete()

            logger.info(f"✅ Order {order.id} created successfully for user {user_email}")

        except Exception as e:
            logger.exception(f"❌ Error processing webhook: {e}")
            return HttpResponse("Webhook processing failed", status=500)

    else:
        logger.info(f"ℹ️ Ignored event type: {event['type']}")

    return HttpResponse("Webhook processed", status=200)