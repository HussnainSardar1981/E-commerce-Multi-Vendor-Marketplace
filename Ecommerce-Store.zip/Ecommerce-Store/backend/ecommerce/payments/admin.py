from django.contrib import admin
from .models import StripeAccount, Payment

@admin.register(StripeAccount)
class StripeAccountAdmin(admin.ModelAdmin):
    list_display = ["shop", "stripe_account_id", "charges_enabled", "details_submitted"]

@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ["order", "amount_received", "currency", "payment_status", "paid_at"]
    search_fields = ["stripe_payment_intent", "order__id"]
