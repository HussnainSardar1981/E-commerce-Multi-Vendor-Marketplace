from django.urls import path
from rest_framework.routers import DefaultRouter
from .views import ShopViewSet, PublicShopViewSet  # Make sure PublicShopViewSet is implemented

shop_create = ShopViewSet.as_view({
    'post': 'create',
})

shop_me = ShopViewSet.as_view({
    'get': 'me',
    'put': 'me',
})

router = DefaultRouter()
router.register(r'public/shops', PublicShopViewSet, basename='public-shops')

urlpatterns = [
    path('create/', shop_create, name='shop-create'),   # POST /api/shops/create/
    path('my-shop/', shop_me, name='shop-me'),          # GET or PUT /api/shops/my-shop/
]

urlpatterns += router.urls
