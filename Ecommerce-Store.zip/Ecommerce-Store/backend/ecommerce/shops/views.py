from rest_framework import viewsets, permissions, status, serializers
from .models import Shop
from .serializers import ShopSerializer
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import AllowAny

class IsSeller(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated and request.user.is_seller


class PublicShopViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Shop.objects.all()
    serializer_class = ShopSerializer
    permission_classes = [AllowAny]

class ShopViewSet(viewsets.ModelViewSet):
    serializer_class = ShopSerializer
    permission_classes = [permissions.IsAuthenticated, IsSeller]

    def get_queryset(self):
        return Shop.objects.filter(owner=self.request.user)

    def perform_create(self, serializer):
        user = self.request.user
        if Shop.objects.filter(owner=user).exists():
            raise serializers.ValidationError("You already have a shop.")
        serializer.save(owner=user)

    @action(detail=False, methods=["get", "put"], url_path="my-shop")
    def me(self, request):
        try:
            shop = Shop.objects.get(owner=request.user)
        except Shop.DoesNotExist:
            return Response({"detail": "No shop found."}, status=status.HTTP_404_NOT_FOUND)

        if request.method == "GET":
            serializer = self.get_serializer(shop)
            return Response(serializer.data)

        elif request.method == "PUT":
            serializer = self.get_serializer(shop, data=request.data)
            serializer.is_valid(raise_exception=True)
            serializer.save()
            print("Authorization header:", request.META.get("HTTP_AUTHORIZATION"))
            return Response(serializer.data)
